# 🧠 ContextFlow — AI-Powered Data Intelligence Platform

## 📦 Structure
| Folder | Description |
|--------|--------------|
| frontend | React + Tailwind interface |
| backend | Flask/FastAPI REST API |
| ai_pipeline | Model training and inference |
| infra | AWS, Docker, Terraform deployment scripts |
| docs | Documentation and references |

## 🚀 Quick Start
