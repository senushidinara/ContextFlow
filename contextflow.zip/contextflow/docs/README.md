# 📘 ContextFlow Documentation
This repo contains all system components: frontend, backend, AI pipeline, infra, and deployment scripts.
