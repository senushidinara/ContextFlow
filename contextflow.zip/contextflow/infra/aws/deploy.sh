#!/bin/bash
# 🚀 AWS One-Click Deployment
aws s3 cp contextflow.zip s3://your-bucket/
aws cloudformation deploy --template-file infra/aws/template.yaml --stack-name contextflow --capabilities CAPABILITY_IAM
